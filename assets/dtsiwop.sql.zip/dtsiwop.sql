-- phpMyAdmin SQL Dump
-- version 2.11.4
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Jul 12, 2012 at 04:51 PM
-- Server version: 5.1.57
-- PHP Version: 5.2.17

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";

--
-- Database: `a2217818_dtsiwop`
--

-- --------------------------------------------------------

--
-- Table structure for table `BACKUP`
--

CREATE TABLE `BACKUP` (
  `wo_num` varchar(11) COLLATE latin1_general_ci NOT NULL,
  `client` varchar(35) COLLATE latin1_general_ci DEFAULT NULL,
  `address` varchar(45) COLLATE latin1_general_ci DEFAULT NULL,
  `city` varchar(45) COLLATE latin1_general_ci DEFAULT NULL,
  `state` varchar(25) COLLATE latin1_general_ci DEFAULT NULL,
  `zip` varchar(12) COLLATE latin1_general_ci DEFAULT NULL,
  `phone` varchar(20) COLLATE latin1_general_ci DEFAULT NULL,
  `fax` varchar(20) COLLATE latin1_general_ci DEFAULT NULL,
  `phone_sys_type` varchar(35) COLLATE latin1_general_ci DEFAULT NULL,
  `vm_sys_type` varchar(35) COLLATE latin1_general_ci DEFAULT NULL,
  `bronze_date` varchar(20) COLLATE latin1_general_ci DEFAULT NULL,
  `silver_date` varchar(20) COLLATE latin1_general_ci DEFAULT NULL,
  `orig_inst_date` varchar(20) COLLATE latin1_general_ci DEFAULT NULL,
  `telco` varchar(35) COLLATE latin1_general_ci DEFAULT NULL,
  `telco_date` varchar(20) COLLATE latin1_general_ci DEFAULT NULL,
  `problem` varchar(300) COLLATE latin1_general_ci DEFAULT NULL,
  `order_date` varchar(20) COLLATE latin1_general_ci DEFAULT NULL,
  `order_contact` varchar(35) COLLATE latin1_general_ci DEFAULT NULL,
  `notes` varchar(100) COLLATE latin1_general_ci DEFAULT NULL,
  `CPU_ver` varchar(20) COLLATE latin1_general_ci DEFAULT NULL,
  `request_date` varchar(20) COLLATE latin1_general_ci DEFAULT NULL,
  `request_time` varchar(20) COLLATE latin1_general_ci DEFAULT NULL,
  `billing_notes` varchar(400) COLLATE latin1_general_ci DEFAULT NULL,
  `work_description` varchar(400) COLLATE latin1_general_ci DEFAULT NULL,
  PRIMARY KEY (`wo_num`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

--
-- Dumping data for table `BACKUP`
--

INSERT INTO `BACKUP` VALUES('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `CLIENTS`
--

CREATE TABLE `CLIENTS` (
  `client` varchar(50) COLLATE latin1_general_ci NOT NULL,
  `address` varchar(75) COLLATE latin1_general_ci DEFAULT NULL,
  `city` varchar(50) COLLATE latin1_general_ci DEFAULT NULL,
  `state` varchar(20) COLLATE latin1_general_ci DEFAULT 'FL',
  `zip` varchar(20) COLLATE latin1_general_ci DEFAULT NULL,
  `phone` varchar(20) COLLATE latin1_general_ci DEFAULT NULL,
  `fax` varchar(20) COLLATE latin1_general_ci DEFAULT NULL,
  `orig_inst` varchar(20) COLLATE latin1_general_ci DEFAULT NULL,
  `telco` varchar(50) COLLATE latin1_general_ci DEFAULT NULL,
  `phone_sys_type` varchar(50) COLLATE latin1_general_ci DEFAULT NULL,
  `vm_sys_type` varchar(50) COLLATE latin1_general_ci DEFAULT NULL,
  `bronze_date` varchar(40) COLLATE latin1_general_ci DEFAULT NULL,
  `silver_date` varchar(40) COLLATE latin1_general_ci DEFAULT NULL,
  `telco_date` varchar(40) COLLATE latin1_general_ci DEFAULT NULL,
  `order_contact` varchar(40) COLLATE latin1_general_ci DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

--
-- Dumping data for table `CLIENTS`
--


-- --------------------------------------------------------

--
-- Table structure for table `CUSTOMER_WORK_ORDERS`
--

CREATE TABLE `CUSTOMER_WORK_ORDERS` (
  `wo_num` varchar(11) COLLATE latin1_general_ci NOT NULL,
  `client` varchar(50) COLLATE latin1_general_ci NOT NULL,
  `address` varchar(75) COLLATE latin1_general_ci DEFAULT NULL,
  `city` varchar(50) COLLATE latin1_general_ci DEFAULT NULL,
  `state` varchar(15) COLLATE latin1_general_ci DEFAULT NULL,
  `zip` varchar(13) COLLATE latin1_general_ci DEFAULT NULL,
  `phone` varchar(15) COLLATE latin1_general_ci DEFAULT NULL,
  `fax` varchar(15) COLLATE latin1_general_ci DEFAULT NULL,
  `orig_inst_date` varchar(20) COLLATE latin1_general_ci DEFAULT NULL,
  `phone_sys_type` varchar(50) COLLATE latin1_general_ci DEFAULT NULL,
  `vm_sys_type` varchar(50) COLLATE latin1_general_ci DEFAULT NULL,
  `bronze_date` varchar(20) COLLATE latin1_general_ci DEFAULT NULL,
  `silver_date` varchar(20) COLLATE latin1_general_ci DEFAULT NULL,
  `telco` varchar(50) COLLATE latin1_general_ci DEFAULT NULL,
  `telco_date` varchar(50) COLLATE latin1_general_ci DEFAULT NULL,
  `problem` varchar(200) COLLATE latin1_general_ci DEFAULT NULL,
  `order_date` varchar(20) COLLATE latin1_general_ci DEFAULT NULL,
  `order_contact` varchar(50) COLLATE latin1_general_ci DEFAULT NULL,
  `notes` varchar(200) COLLATE latin1_general_ci DEFAULT NULL,
  `CPU_ver` varchar(20) COLLATE latin1_general_ci DEFAULT NULL,
  `request_date` varchar(20) COLLATE latin1_general_ci DEFAULT NULL,
  `request_time` varchar(20) COLLATE latin1_general_ci DEFAULT NULL,
  `billing_notes` varchar(200) COLLATE latin1_general_ci DEFAULT NULL,
  `work_description` varchar(350) COLLATE latin1_general_ci DEFAULT NULL,
  PRIMARY KEY (`wo_num`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

--
-- Dumping data for table `CUSTOMER_WORK_ORDERS`
--


-- --------------------------------------------------------

--
-- Table structure for table `password`
--

CREATE TABLE `password` (
  `password` varchar(40) COLLATE latin1_general_ci NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

--
-- Dumping data for table `password`
--

INSERT INTO `password` VALUES('1ca218a9233e0deca14c8843ae541e88');
